# Foot Talent

> Les talents de demain, l’actualité d’aujourd’hui.

Site du média Foot Talent : football de formation, U17 et U19 Nationaux, jeunes talents, centres de formation,
interviews et analyses.

**Guide complet (mise en ligne, administration, checklist de lancement) : [GUIDE-ADMINISTRATION.md](GUIDE-ADMINISTRATION.md).**

## Démarrer en local

Prérequis : Node.js 22.

```bash
npm install
npm run dev          # http://localhost:4321 (brouillons et articles programmés visibles en local)
npm run build        # construit le site dans dist/ et l’index de recherche
npm run preview      # sert le site construit
npm run check:content  # vérifications éditoriales (démo restante, mineurs, crédits, images)
npm run demo:remove    # supprime tous les contenus de démonstration
```

Administration en local, sans GitHub : lancez `npm run dev`, ouvrez `http://localhost:4321/admin/` dans Chrome ou Edge,
puis « Travailler avec un dépôt local » et sélectionnez ce dossier.

## Organisation

```
src/content/articles/   Articles (Markdown + en-tête de métadonnées)
src/content/rubriques/  Rubriques du menu
src/content/clubs/      Clubs (pages éditoriales)
src/content/auteurs/    Auteurs
src/data/               Réglages : site, page d’accueil, radar U17/U19, publicités
src/pages/              Pages du site (accueil, rubriques, articles, partenaires, légal, RSS, sitemap, robots)
src/components/         En-tête, pied de page, cartes, radar, newsletter, publicité, partage, logo
public/admin/           Administration (Sveltia CMS) et sa configuration
public/brand/           Logos (fond clair, fond sombre, symbole)
public/_headers         En-têtes de sécurité (Cloudflare Pages)
scripts/                Vérifications, suppression de la démo, générateurs du logo et des visuels de démo
.github/workflows/      Publication programmée, vérification, sauvegarde hebdomadaire
```

## Règles intégrées

- Un article n’est publié que si : statut « Publié », date atteinte, droits d’image cochés, et — s’il concerne un mineur —
  autorisations des représentants légaux cochées. Les articles bloqués sont signalés dans le journal de construction.
- Le radar U17/U19 n’affiche que des données marquées « Vérifié » et accompagnées d’une source.
- Les contenus de démonstration (`demo: true`) portent un avertissement visible, ne sont jamais indexés et sont exclus du sitemap et du flux RSS.
- Tant que « Autoriser les moteurs de recherche » est désactivé, `robots.txt` bloque l’indexation et chaque page porte `noindex`.
- Contenus partenaires et publicités toujours étiquetés.

## Identité visuelle

- Couleurs : nuit `#0B1D3A`, abysse `#06122A`, blanc `#FFFFFF`, vert `#1EE38A` (texte vert sur blanc : `#087446`).
- Typographies (auto-hébergées, aucune requête vers Google) : Big Shoulders Display (titres), Barlow (texte).
- Logo : `public/brand/` — versions fond clair, fond sombre, symbole seul (SVG, et PNG 512 px).
- Les visuels de démonstration de `public/images/demo/` sont des illustrations originales générées par
  `scripts/brand/visuels-demo.html` : libres de droits, à remplacer par de vraies photos.
