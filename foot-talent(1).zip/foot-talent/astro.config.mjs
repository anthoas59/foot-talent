// @ts-check
import { defineConfig } from 'astro/config';
import { readFileSync } from 'node:fs';

const settings = JSON.parse(readFileSync(new URL('./src/data/reglages.json', import.meta.url), 'utf8'));

export default defineConfig({
  // Adresse publique du site : modifiable dans l'administration (Réglages du site > Adresse du site)
  site: process.env.SITE_URL || settings.url,
  trailingSlash: 'always',
  build: { format: 'directory' },
  prefetch: { prefetchAll: false, defaultStrategy: 'hover' },
});
