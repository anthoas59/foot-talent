// Indique si un article programmé vient d'atteindre sa date de publication
// (utilisé par la tâche horaire GitHub « Publication programmée »).
// Sortie : "oui" ou "non". Fenêtre par défaut : 70 minutes.
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';

const dossier = new URL('../src/content/articles/', import.meta.url).pathname;
const fenetre = Number(process.env.FENETRE_MINUTES || 70) * 60e3;
const maintenant = Date.now();
const dus = [];
for (const f of readdirSync(dossier).filter((f) => f.endsWith('.md'))) {
  const fm = readFileSync(join(dossier, f), 'utf8').split('---')[1] ?? '';
  const statut = fm.match(/^statut:\s*"?(\w+)"?/m)?.[1];
  const date = Date.parse((fm.match(/^date:\s*"?([^"\n]+)"?/m)?.[1] ?? '').trim());
  if (statut === 'publie' && date <= maintenant && date > maintenant - fenetre) dus.push(f);
}
if (dus.length) console.error('Articles à publier : ' + dus.join(', '));
console.log(dus.length ? 'oui' : 'non');
