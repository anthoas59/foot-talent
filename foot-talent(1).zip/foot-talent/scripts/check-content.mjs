// Vérifications éditoriales avant mise en ligne : npm run check:content
// - signale les contenus de démonstration restants
// - signale les articles concernant un mineur sans autorisations
// - signale les images sans texte alternatif ou sans crédit
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const racine = new URL('..', import.meta.url).pathname;
const dossier = join(racine, 'src/content/articles');
const reglages = JSON.parse(readFileSync(join(racine, 'src/data/reglages.json'), 'utf8'));
const champ = (fm, k) => (fm.match(new RegExp(`^${k}:\\s*(.*)$`, 'm'))?.[1] ?? '').replace(/^"|"$/g, '').trim();

let demo = 0, alertes = [], erreurs = [];
for (const f of readdirSync(dossier).filter((f) => f.endsWith('.md'))) {
  const txt = readFileSync(join(dossier, f), 'utf8');
  const fm = txt.split('---')[1] ?? '';
  if (champ(fm, 'demo') === 'true') demo++;
  const publie = champ(fm, 'statut') === 'publie';
  if (publie && champ(fm, 'concerne_mineur') === 'true' && champ(fm, 'autorisations_mineur') !== 'true')
    alertes.push(`${f} : concerne un mineur, autorisations non cochées (l’article reste masqué).`);
  if (publie && champ(fm, 'images_droits_verifies') !== 'true') alertes.push(`${f} : droits d’image non vérifiés (l’article reste masqué).`);
  if (!champ(fm, 'image_alt')) erreurs.push(`${f} : texte alternatif de l’image manquant.`);
  if (!champ(fm, 'image_credit')) erreurs.push(`${f} : crédit photo manquant.`);
  const img = champ(fm, 'image');
  if (img.startsWith('/') && !existsSync(join(racine, 'public', img))) erreurs.push(`${f} : image introuvable (${img}).`);
}

console.log('\nVérification des contenus Foot Talent\n');
if (demo) console.log(`• ${demo} article(s) de démonstration présents. Avant le lancement : npm run demo:remove`);
alertes.forEach((a) => console.log('• ' + a));
erreurs.forEach((e) => console.log('✗ ' + e));
if (reglages.indexation && demo) {
  console.log('✗ L’indexation est activée alors que des contenus de démonstration existent.');
  process.exitCode = 1;
}
if (erreurs.length) process.exitCode = 1;
if (!demo && !alertes.length && !erreurs.length) console.log('Tout est en ordre.');
console.log('');
