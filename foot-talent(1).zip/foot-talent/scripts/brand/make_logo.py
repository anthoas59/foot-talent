"""Génère les fichiers du logo Foot Talent (texte vectorisé, aucune police requise)."""
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
import sys, pathlib
FONT = "node_modules/@fontsource-variable/big-shoulders-display/files/big-shoulders-display-latin-wght-normal.woff2"
f = TTFont(FONT); f = instantiateVariableFont(f, {"wght": 850})
gs = f.getGlyphSet(); cmap = f.getBestCmap(); upm = f["head"].unitsPerEm
hmtx = f["hmtx"]
def text_path(txt, size, x0, baseline, track=0):
    pen = SVGPathPen(gs); s = size/upm; x = x0
    for ch in txt:
        g = cmap[ord(ch)]
        tp = TransformPen(pen, (s,0,0,-s,x,baseline))
        gs[g].draw(tp)
        x += hmtx[g][0]*s + track
    return pen.getCommands(), x
out = pathlib.Path("public/brand")
NAVY="#0B1D3A"; GREEN="#1EE38A"; WHITE="#FFFFFF"
# Symbole : un ballon qui se lève au-dessus de la ligne de touche
def mark(x, y, s, bg, ball, line, rounded=True):
    r = s*0.2 if rounded else 0
    u = s/64
    def P(px,py): return f"{x+px*u:.2f} {y+py*u:.2f}"
    # trajectoire montante + ballon : le talent qui decolle
    return f'''<rect x="{x}" y="{y}" width="{s}" height="{s}" rx="{r:.1f}" fill="{bg}"/>
<path d="M{P(9,53)} C{P(17,52.5)} {P(24,48)} {P(29,40)}" fill="none" stroke="{line}" stroke-width="{4.6*u:.2f}" stroke-linecap="round"/><path d="M{P(9,44)} C{P(13,43.6)} {P(16.5,42)} {P(19.5,39.5)}" fill="none" stroke="{line}" stroke-width="{3*u:.2f}" stroke-linecap="round" opacity=".55"/>
<circle cx="{x+42*u:.2f}" cy="{y+22*u:.2f}" r="{12.5*u:.2f}" fill="{ball}"/>
<path d="M{P(42,15.6)} l{6*u:.2f} {4.35*u:.2f} l{-2.3*u:.2f} {7.05*u:.2f} h{-7.4*u:.2f} l{-2.3*u:.2f} {-7.05*u:.2f} Z" fill="{bg}"/>'''
def logo(file, word1, word2, bgmark, ball, line, w1col, w2col, page_bg=None):
    S=64; gap=14
    p1, x1 = text_path("FOOT", 52, S+gap, 52, 1.5)
    p2, x2 = text_path("TALENT", 52, x1+11, 52, 1.5)
    W = x2+2
    bg = f'<rect width="{W:.0f}" height="{S}" fill="{page_bg}"/>' if page_bg else ""
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W:.0f} {S}" width="{W:.0f}" height="{S}" role="img" aria-label="Foot Talent">
<title>Foot Talent</title>{bg}
{mark(0,0,S,bgmark,ball,line)}
<path d="{p1}" fill="{w1col}"/><path d="{p2}" fill="{w2col}"/>
</svg>'''
    (out/file).write_text(svg); return W
w = logo("foot-talent-logo-fond-clair.svg","","",NAVY,GREEN,WHITE,NAVY,NAVY)
logo("foot-talent-logo-fond-sombre.svg","","",GREEN,NAVY,NAVY,WHITE,GREEN)
# symbole seul
for name,bg,ball,line in [("foot-talent-symbole.svg",NAVY,GREEN,WHITE),("foot-talent-symbole-vert.svg",GREEN,NAVY,NAVY)]:
    (out/name).write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64"><title>Foot Talent</title>{mark(0,0,64,bg,ball,line)}</svg>')
(pathlib.Path("public")/"favicon.svg").write_text((out/"foot-talent-symbole.svg").read_text())
# signature + wordmark paths for header component (currentColor version)
p1, x1 = text_path("FOOT", 52, 0, 52, 1.5); p2, x2 = text_path("TALENT", 52, x1+11, 52, 1.5)
pathlib.Path("src/components").mkdir(parents=True, exist_ok=True)
pathlib.Path("src/components/wordmark.json").write_text(__import__("json").dumps({"foot":p1,"talent":p2,"width":round(x2+2,1)}))
print("ok", w)
