"""Crée les articles de démonstration (tous fictifs, marqués demo: true).
Lancé une seule fois à la création du projet ; conservé pour pouvoir régénérer la démo."""
import pathlib, json

OUT = pathlib.Path(__file__).resolve().parent.parent / "src/content/articles"
OUT.mkdir(parents=True, exist_ok=True)

def yaml_val(v):
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, (int, float)): return str(v)
    if v is None: return "null"
    return json.dumps(v, ensure_ascii=False)

def front(d, indent=0):
    out = []
    pad = "  " * indent
    for k, v in d.items():
        if isinstance(v, dict):
            out.append(f"{pad}{k}:"); out.append(front(v, indent + 1))
        elif isinstance(v, list):
            if not v: out.append(f"{pad}{k}: []")
            else:
                out.append(f"{pad}{k}:"); out += [f"{pad}  - {yaml_val(i)}" for i in v]
        else:
            out.append(f"{pad}{k}: {yaml_val(v)}")
    return "\n".join(out)

BASE = dict(statut="publie", images_droits_verifies=True, concerne_mineur=False, autorisations_mineur=False,
            sponsorise=False, noindex=False, demo=True, image_credit="Illustration Foot Talent (visuel de démonstration)")

A = []
def art(slug, body, **fm):
    d = dict(BASE); d.update(fm); A.append((slug, d, body.strip() + "\n"))

art("demo-generation-2010-ce-que-les-centres-de-formation-cherchent-vraiment",
    titre="Génération 2010 : ce que les centres de formation cherchent vraiment",
    chapo="Vitesse, technique, mental : derrière les mots qu’on entend partout, les recruteurs de formation décrivent des critères plus fins. Exemple de grand format, rédigé pour la démonstration du site.",
    rubrique="centres-de-formation", format="analyse", auteur="demo-lea-morvan", date="2026-10-24T08:30:00+02:00",
    image="/images/demo/stade-nuit.webp", image_alt="Illustration d’un stade éclairé de nuit, vu depuis le bord du terrain",
    clubs=["demo-fc-valbrune", "demo-as-montclair"], mots_cles=["formation", "recrutement", "U17"],
    seo_description="Ce que les centres de formation regardent chez un joueur de 16 ans : un exemple de grand format Foot Talent.",
    body="""
> Article de démonstration. Les clubs et personnes cités sont fictifs ; aucune information de cet article ne doit être lue comme une actualité.

Dans un centre de formation, la première observation dure rarement plus d’une mi-temps. Ce n’est pourtant pas le moment où se prend la décision. Ce qui compte, racontent les éducateurs, c’est la répétition : revoir le même joueur sur plusieurs matchs, dans des contextes différents, face à des adversaires de niveaux différents.

## La prise d’information avant le geste

Le critère qui revient le plus souvent n’est pas spectaculaire. Avant de recevoir le ballon, le joueur a-t-il regardé autour de lui ? Sait-il déjà où il va le transmettre ? Cette capacité à « scanner » le jeu se voit dès 15 ou 16 ans, et elle progresse moins vite que la technique pure.

Au FC Valbrune, club fictif imaginé pour cet exemple, les éducateurs filment les séances sous deux angles pour isoler ces moments-là. L’objectif n’est pas de noter le joueur, mais de lui montrer ce qu’il voit et ce qu’il manque.

## La réaction après l’erreur

Deuxième critère : ce qui se passe dans les dix secondes qui suivent une perte de balle. Un joueur qui baisse la tête et un joueur qui repart immédiatement au pressing ne racontent pas la même histoire. Pour un centre de formation, c’est une indication précieuse sur la façon dont il vivra les années difficiles qui l’attendent.

## Le profil physique, avec prudence

Entre 15 et 17 ans, les écarts de maturité physique sont considérables. Les formateurs le savent : un joueur plus petit aujourd’hui peut avoir rattrapé tout le monde dans deux ans. Beaucoup de structures tiennent désormais compte de l’âge biologique, et pas seulement de la date de naissance, pour éviter de passer à côté des profils plus tardifs.

## Ce que cela change pour les familles

Pour les parents, le message des éducateurs est constant : la régularité compte plus qu’un match exceptionnel, et le projet scolaire reste un critère d’équilibre. Un bon centre de formation pose autant de questions sur l’école que sur le terrain.
""")

art("demo-u19-nationaux-pourquoi-le-pressing-haut-change-la-donne",
    titre="U19 Nationaux : pourquoi le pressing haut change la donne",
    chapo="De plus en plus d’équipes de jeunes défendent en avançant. Décryptage, à partir d’un match fictif, de ce que cette approche exige des joueurs.",
    rubrique="u19-nationaux", format="analyse", auteur="demo-hugo-valette", date="2026-10-23T18:00:00+02:00",
    image="/images/demo/tableau-tactique.webp", image_alt="Schéma tactique : deux équipes en position, flèches montrant un déclenchement de pressing",
    clubs=["demo-olympique-port-lumiere", "demo-stade-riviere-haute"], mots_cles=["tactique", "pressing", "U19"],
    body="""
> Analyse de démonstration fondée sur une situation de jeu imaginaire. Aucun résultat ni aucune statistique réels ne sont présentés.

Le pressing haut n’est plus réservé aux équipes professionnelles. En catégories de jeunes, il est devenu un outil de formation à part entière : il oblige chaque joueur à lire le jeu, à communiquer et à courir avec intelligence plutôt qu’en quantité.

## Le déclencheur, plus important que l’intensité

Sur le schéma ci-dessus, le pressing ne démarre pas au hasard. Il se déclenche sur une passe latérale vers le défenseur excentré : c’est le signal. Le milieu le plus proche ferme la ligne de passe intérieure, l’attaquant coupe le retour vers le gardien. L’adversaire n’a plus qu’une option, la plus difficile.

## Ce que les éducateurs travaillent

- **La synchronisation** : presser seul ne sert à rien, presser à trois change tout.
- **La couverture** : derrière la première ligne, les défenseurs doivent remonter pour réduire l’espace.
- **La lucidité** : savoir quand ne pas presser, notamment en fin de match.

## Une école de la décision

Pour un joueur de 18 ans, ces séquences sont exigeantes. Elles préparent pourtant à ce qui l’attend au niveau supérieur, où les décisions se prennent en une fraction de seconde. C’est sans doute la meilleure raison de suivre ces matchs de près.
""")

art("demo-entretien-educatrice-formation-la-patience-est-une-methode",
    titre="« La patience est une méthode » : entretien avec une éducatrice de formation",
    chapo="Elle encadre des moins de 17 ans depuis dix ans. Exemple d’interview au format questions-réponses, avec une interlocutrice fictive.",
    rubrique="interviews", format="interview", auteur="demo-lea-morvan", date="2026-10-22T07:00:00+02:00",
    image="/images/demo/micro-interview.webp", image_alt="Illustration d’un micro d’interview devant des lumières de stade floues",
    interviewe=dict(nom="Claire Antunes (personnage fictif)", fonction="Éducatrice U17"),
    citation="Un joueur ne progresse pas en ligne droite. Notre travail, c’est d’accepter les paliers.",
    mots_cles=["éducateurs", "méthode", "U17"],
    body="""
> Interview de démonstration : la personne interrogée est un personnage fictif.

**Qu’est-ce qui a le plus changé dans la formation depuis vos débuts ?**

La place de la vidéo et du dialogue. Avant, on disait au joueur ce qu’il avait mal fait. Aujourd’hui, on lui montre la séquence et on lui demande ce qu’il a vu. Il trouve souvent la réponse tout seul, et il la retient beaucoup mieux.

**Comment gérez-vous les joueurs qui progressent moins vite ?**

Un joueur ne progresse pas en ligne droite. Notre travail, c’est d’accepter les paliers. Certains stagnent six mois puis franchissent un cap en trois semaines. Si on les juge au mauvais moment, on se trompe.

**Quelle place pour l’école ?**

Centrale. Le football professionnel ne concernera qu’une minorité de nos joueurs. Tous les autres doivent sortir de chez nous avec un diplôme, un projet et de bonnes habitudes de travail. C’est aussi notre responsabilité.

**Un conseil aux parents ?**

Rester des parents. Les jeunes ont déjà un entraîneur. Ce dont ils ont besoin à la maison, c’est de soutien, pas d’une deuxième analyse du match.
""")

art("demo-pepite-joueur-fictif-milieu-relayeur",
    titre="La pépite du week-end : Noah Valmont, le relayeur qui ne perd jamais le fil",
    chapo="Exemple de portrait pour la rubrique « La pépite du week-end ». Le joueur présenté est entièrement fictif.",
    rubrique="jeunes-talents", format="portrait", auteur="redaction", date="2026-10-24T19:00:00+02:00",
    image="/images/demo/maillot-portrait.webp", image_alt="Illustration d’un maillot vert suspendu dans un vestiaire",
    concerne_mineur=True, autorisations_mineur=True, clubs=["demo-fc-valbrune"], mots_cles=["portrait", "milieu de terrain"],
    pepite=dict(nom_affiche="Noah Valmont", poste="Milieu relayeur", categorie="U17 Nationaux", club="FC Valbrune (club fictif)",
                pourquoi=["Une prise d’information constante avant chaque contrôle", "Une activité défensive rare pour son poste", "Une progression régulière, sans à-coups, depuis le début de saison"]),
    body="""
> Portrait de démonstration : Noah Valmont et le FC Valbrune n’existent pas. Pour un vrai portrait de joueur mineur, vérifiez les autorisations des représentants légaux avant publication.

Il ne marque pas beaucoup, il ne dribble pas trois adversaires, et pourtant on ne regarde que lui. Noah Valmont est de ces milieux de terrain qui rendent le jeu de leur équipe plus simple.

## Un joueur de liaison

Son rôle ? Faire le lien entre la défense et l’attaque. Il décroche entre ses défenseurs centraux pour aider à la relance, puis se projette dès que son équipe franchit la ligne médiane. Ses éducateurs saluent surtout sa constance : il fait les mêmes efforts à la 85e minute qu’à la 5e.

## Ce qui le distingue

Avant chaque réception de balle, il tourne la tête deux, parfois trois fois. Ce réflexe, travaillé depuis ses débuts en école de football, lui donne un temps d’avance sur ses adversaires.

## La suite

Pas question de brûler les étapes. Son entourage insiste sur l’équilibre entre le football et la scolarité. C’est aussi ce qui fait de lui un joueur à suivre : il construit sa progression sur la durée.

*Pourquoi nous ne publions pas certaines informations : pour les joueurs mineurs, Foot Talent ne publie ni date de naissance complète, ni lieu de résidence, ni établissement scolaire.*
""")

art("demo-u17-nationaux-ce-qu-il-faut-regarder-cette-saison",
    titre="U17 Nationaux : cinq choses à regarder cette saison",
    chapo="Formats, temps de jeu, profils : un guide de lecture pour suivre le championnat national des moins de 17 ans. Exemple d’article de démonstration.",
    rubrique="u17-nationaux", format="actualite", auteur="demo-hugo-valette", date="2026-10-21T12:00:00+02:00",
    image="/images/demo/pelouse-ballon.webp", image_alt="Ballon posé sur une pelouse rayée près du rond central",
    mots_cles=["U17", "guide"],
    body="""
> Article de démonstration. Il ne contient volontairement ni résultat ni classement.

Le championnat national U17 est souvent la première vitrine nationale pour un joueur formé en club. Voici cinq repères pour le suivre avec un œil d’observateur.

## 1. Le temps de jeu des plus jeunes

Les joueurs surclassés, qui évoluent avec des partenaires plus âgés, sont un indicateur intéressant de la confiance que leur accordent les éducateurs.

## 2. Les gardiens

Le poste le plus difficile à évaluer chez les jeunes, et souvent le plus sous-estimé. Le jeu au pied est devenu un critère central.

## 3. Les animations offensives

Certaines équipes privilégient la possession, d’autres les transitions rapides. Ces choix reflètent la philosophie du centre de formation.

## 4. Les remplacements

En catégories de jeunes, ils servent aussi à faire progresser. Observer qui entre, et à quel moment, dit beaucoup.

## 5. La gestion des temps faibles

Une équipe qui sait souffrir sans se désorganiser est souvent une équipe bien formée.
""")

art("demo-la-transition-u19-vers-le-monde-senior",
    titre="De l’U19 au monde senior : la marche la plus haute",
    chapo="Intensité, concurrence, attentes : pourquoi le passage chez les seniors reste le moment le plus délicat d’une trajectoire. Exemple d’article.",
    rubrique="u19-nationaux", format="actualite", auteur="demo-lea-morvan", date="2026-10-19T09:00:00+02:00",
    image="/images/demo/filet-but.webp", image_alt="Ballon dans un filet de but, lumières de stade en arrière-plan",
    mots_cles=["U19", "transition", "seniors"],
    body="""
> Article de démonstration : aucune situation réelle n’est décrite.

À 18 ou 19 ans, un joueur de centre de formation découvre un football différent. Les adversaires ont dix ans d’expérience de plus, les matchs comptent pour des points qui pèsent sur une saison entière, et la marge d’erreur se réduit.

## Une question de rythme

Le premier choc est physique. Les duels sont plus longs, les courses plus répétées. Les préparateurs physiques des centres de formation anticipent ce passage en augmentant progressivement les charges de travail dès la catégorie U19.

## Une question d’environnement

Le second choc est humain. Le joueur quitte un groupe d’amis du même âge pour un vestiaire d’adultes. L’accompagnement des éducateurs et des familles joue alors un rôle déterminant.
""")

art("demo-analyse-occuper-le-demi-espace-en-u17",
    titre="Occuper le demi-espace : la zone que les formateurs adorent",
    chapo="Entre le couloir et l’axe, une bande de terrain concentre de plus en plus d’attention dans la formation des milieux offensifs. Analyse de démonstration.",
    rubrique="analyses", format="analyse", auteur="demo-hugo-valette", date="2026-10-17T10:00:00+02:00",
    image="/images/demo/heatmap-analyse.webp", image_alt="Carte de chaleur illustrative montrant une zone d’activité dans le demi-espace droit",
    mots_cles=["tactique", "demi-espace", "formation"],
    body="""
> Analyse de démonstration : la carte de chaleur est une illustration, elle ne représente aucune donnée réelle.

Le demi-espace, c’est cette zone située entre le couloir latéral et l’axe du terrain. Un joueur qui la reçoit peut aussi bien centrer que frapper, combiner vers l’intérieur ou servir un partenaire lancé dans la profondeur.

## Pourquoi les centres de formation la travaillent

Recevoir dans le demi-espace oblige à maîtriser le contrôle orienté et la prise d’information. Ce sont deux compétences que les éducateurs considèrent comme fondamentales.

## Comment l’observer depuis la tribune

Regardez où se positionnent les milieux offensifs quand leur équipe a le ballon dans son propre camp. S’ils se décalent entre les lignes adverses, à mi-chemin entre la ligne de touche et l’axe, c’est que le plan de jeu a été travaillé.
""")

art("demo-une-journee-dans-un-centre-de-formation",
    titre="Une journée dans un centre de formation, de 7 h à 21 h",
    chapo="École, entraînement, soins, devoirs : à quoi ressemble le quotidien d’un apprenti footballeur. Reportage de démonstration dans un centre imaginaire.",
    rubrique="centres-de-formation", format="actualite", auteur="demo-lea-morvan", date="2026-10-15T08:00:00+02:00",
    image="/images/demo/centre-formation.webp", image_alt="Plots et échelle de rythme disposés sur un terrain d’entraînement",
    clubs=["demo-as-montclair"], mots_cles=["reportage", "quotidien", "formation"],
    body="""
> Reportage de démonstration au sein d’un centre fictif.

7 heures. Le réveil sonne à l’internat de l’AS Montclair, club imaginé pour cet exemple. Avant le premier ballon, il y a le petit-déjeuner, puis la route vers le lycée partenaire.

## Le matin, l’école d’abord

Les emplois du temps sont aménagés, mais les exigences restent les mêmes. Les éducateurs suivent les bulletins de près : un joueur en difficulté scolaire peut voir son temps d’entraînement réduit au profit du soutien.

## L’après-midi, le terrain

La séance du jour porte sur la prise de balle sous pression. Ateliers courts, consignes précises, vidéo en fin de séance.

## Le soir, la récupération

Soins, repas, devoirs. À 21 heures, le calme revient. Demain, tout recommence.
""")

art("demo-entretien-recruteur-ce-que-je-regarde-en-premier",
    titre="« Je regarde d’abord ce qu’il fait sans le ballon »",
    chapo="Rencontre avec un recruteur de formation (personnage fictif) qui détaille sa méthode d’observation. Exemple d’interview.",
    rubrique="interviews", format="interview", auteur="redaction", date="2026-10-13T07:30:00+02:00",
    image="/images/demo/filet-but.webp", image_alt="Ballon dans un filet de but sous les projecteurs",
    interviewe=dict(nom="Marc Delorme (personnage fictif)", fonction="Recruteur de formation"),
    citation="Un joueur passe 88 minutes sans le ballon. C’est là que je l’observe vraiment.",
    mots_cles=["recrutement", "observation"],
    body="""
> Interview de démonstration : le recruteur interrogé est un personnage fictif.

**Que regardez-vous en premier quand vous observez un joueur ?**

Ce qu’il fait sans le ballon. Un joueur passe l’essentiel du match sans le toucher. C’est là que je l’observe vraiment : ses placements, ses courses, la façon dont il parle à ses partenaires.

**Combien de fois voyez-vous un joueur avant de le recommander ?**

Jamais une seule. Je veux le voir dans un bon match, dans un match difficile, à domicile et à l’extérieur. Une impression ne suffit pas.

**Les statistiques comptent-elles ?**

Elles complètent l’observation, elles ne la remplacent pas. Chez les jeunes, les données sont rares et doivent être maniées avec prudence.
""")

art("demo-contenu-partenaire-equipement-des-ecoles-de-foot",
    titre="Équiper une école de football : les besoins prioritaires des clubs",
    chapo="Exemple de contenu partenaire. Ce format est réservé aux articles réalisés avec un annonceur et toujours signalé comme tel.",
    rubrique="centres-de-formation", format="actualite", auteur="redaction", date="2026-10-11T10:00:00+02:00",
    image="/images/demo/pelouse-ballon.webp", image_alt="Ballon sur une pelouse rayée",
    sponsorise=True, partenaire_nom="Partenaire fictif (exemple)", partenaire_url="",
    mots_cles=["partenaire", "équipement"],
    body="""
> Contenu partenaire de démonstration. Le partenaire cité n’existe pas.

Ballons adaptés à chaque catégorie, plots, mini-buts, chasubles : l’équipement d’une école de football représente un poste de dépense important pour les clubs amateurs.

## Prioriser selon les catégories

Pour les plus jeunes, la taille et le poids des ballons comptent davantage que leur prix. Pour les catégories plus âgées, ce sont les outils de travail spécifiques (mannequins, échelles de rythme) qui font la différence.

*Ce contenu a été réalisé en partenariat. La rédaction de Foot Talent n’a pas participé à sa rédaction.*
""")

art("demo-u17-programme-resume-de-journee",
    titre="U17 Nationaux : le résumé de journée (exemple de publication programmée)",
    chapo="Cet article est programmé : il n’apparaîtra sur le site qu’à sa date de publication. Il sert à tester la publication différée.",
    rubrique="u17-nationaux", format="resume", auteur="redaction", date="2026-10-28T09:00:00+01:00",
    image="/images/demo/tableau-tactique.webp", image_alt="Schéma tactique illustratif",
    mots_cles=["programmé"],
    body="""
> Article de démonstration programmé.

Un résumé de journée ne doit contenir que des résultats vérifiés auprès d’une source officielle, cités avec leur source.
""")

art("demo-portrait-bloque-autorisations-manquantes",
    titre="Portrait bloqué : autorisations manquantes (exemple de garde-fou)",
    chapo="Cet article concerne un joueur mineur mais les autorisations n’ont pas été cochées : le site refuse de le publier.",
    rubrique="jeunes-talents", format="portrait", auteur="redaction", date="2026-10-20T09:00:00+02:00",
    image="/images/demo/maillot-portrait.webp", image_alt="Illustration d’un maillot",
    concerne_mineur=True, autorisations_mineur=False,
    body="""
> Démonstration du garde-fou de protection des mineurs. Cet article n’apparaît jamais sur le site public.
""")

for slug, d, body in A:
    (OUT / f"{slug}.md").write_text(f"---\n{front(d)}\n---\n\n{body}")
print(len(A), "articles")
