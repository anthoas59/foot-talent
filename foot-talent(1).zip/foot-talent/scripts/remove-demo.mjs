// Supprime tous les contenus de démonstration : npm run demo:remove
// (articles, clubs et auteurs marqués « demo », visuels de démonstration)
// puis remet la page d'accueil sur « article le plus récent ».
import { readFileSync, readdirSync, rmSync, writeFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const racine = new URL('..', import.meta.url).pathname;
const supprimes = [];
for (const [dossier, ext] of [['articles', '.md'], ['clubs', '.json'], ['auteurs', '.json']]) {
  const d = join(racine, 'src/content', dossier);
  for (const f of readdirSync(d).filter((f) => f.endsWith(ext))) {
    const txt = readFileSync(join(d, f), 'utf8');
    const estDemo = ext === '.md' ? /^demo:\s*true\s*$/m.test(txt.split('---')[1] ?? '') : JSON.parse(txt).demo === true;
    if (estDemo) { rmSync(join(d, f)); supprimes.push(`${dossier}/${f}`); }
  }
}
const visuels = join(racine, 'public/images/demo');
if (existsSync(visuels)) { rmSync(visuels, { recursive: true }); supprimes.push('public/images/demo/'); }

const accueil = join(racine, 'src/data/accueil.json');
const a = JSON.parse(readFileSync(accueil, 'utf8'));
a.a_la_une = ''; a.secondaires = []; a.pepite = '';
writeFileSync(accueil, JSON.stringify(a, null, 2) + '\n');

const reglages = join(racine, 'src/data/reglages.json');
const r = JSON.parse(readFileSync(reglages, 'utf8'));
r.mode_demo = false;
writeFileSync(reglages, JSON.stringify(r, null, 2) + '\n');

console.log(`\n${supprimes.length} élément(s) de démonstration supprimé(s) :`);
supprimes.forEach((s) => console.log('  - ' + s));
console.log('\nLe bandeau « Site en préparation » est désactivé. Pensez à choisir l’article à la une et la pépite dans l’administration,');
console.log('puis à activer « Autoriser les moteurs de recherche » dans Réglages > Informations du site.\n');
