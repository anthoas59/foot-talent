# Foot Talent — guide de mise en ligne et d’administration

Ce guide vous accompagne de la mise en ligne jusqu’à la publication de votre premier vrai article.
Aucune connaissance en code n’est nécessaire après l’étape 3.

---

## Comment fonctionne le site

| Élément | Choix | Pourquoi |
|---|---|---|
| Site public | **Astro** (pages HTML statiques) | Très rapide, excellent pour le référencement, presque rien à pirater côté serveur |
| Stockage des articles | Fichiers dans un **dépôt GitHub** privé | Persistant, chaque version est conservée (historique complet = sauvegarde) |
| Administration | **Sveltia CMS** à l’adresse `/admin/` | Interface d’édition en français, gratuite, sans base de données à entretenir |
| Connexion à l’administration | Compte **GitHub** | Seules les personnes que vous ajoutez au dépôt peuvent publier |
| Hébergement | **Cloudflare Pages** (gratuit) | Bande passante illimitée, HTTPS automatique, mise en ligne à chaque publication |
| Recherche | **Pagefind** | Moteur de recherche intégré, gratuit, sans service externe |

**Le cycle d’une publication :** vous enregistrez un article dans `/admin/` → il est enregistré dans GitHub →
Cloudflare reconstruit le site → l’article est en ligne environ 1 à 2 minutes plus tard.

---

## Étape 1 — Créer le dépôt GitHub (10 min)

1. Créez un compte sur [github.com](https://github.com) si vous n’en avez pas.
2. Créez un dépôt **privé** nommé `foot-talent` (bouton « New repository »).
3. Envoyez-y le dossier du projet (le fichier ZIP fourni, décompressé) :
   - le plus simple : sur la page du dépôt vide, lien « uploading an existing file », puis glissez-déposez **tout le contenu** du dossier (sauf `node_modules` s’il existe) ;
   - ou, si vous utilisez Git : `git init && git add . && git commit -m "Foot Talent" && git branch -M main && git remote add origin https://github.com/VOTRE-COMPTE/foot-talent.git && git push -u origin main`.
4. Ouvrez le fichier `public/admin/config.yml` dans GitHub (icône crayon) et remplacez
   `VOTRE-COMPTE-GITHUB/foot-talent` par votre vrai nom de compte et de dépôt.

## Étape 2 — Mettre le site en ligne avec Cloudflare Pages (10 min)

1. Créez un compte gratuit sur [dash.cloudflare.com](https://dash.cloudflare.com).
2. **Workers & Pages → Créer → Pages → Connecter à Git**, choisissez le dépôt `foot-talent`.
3. Réglages de construction :
   - Framework : **Astro**
   - Commande de build : `npm run build`
   - Dossier de sortie : `dist`
   - Variable d’environnement : `NODE_VERSION` = `22`
4. Lancez le déploiement. Le site est disponible sur une adresse du type `foot-talent.pages.dev`.
5. **Nom de domaine** : achetez `foot-talent.fr` (ou autre) chez un registraire (OVHcloud, Gandi, Cloudflare…),
   puis dans Cloudflare Pages → *Domaines personnalisés* → ajoutez `www.foot-talent.fr`.
6. Dans l’administration (plus tard) : **Réglages → Informations du site → Adresse du site**, indiquez l’adresse définitive.

## Étape 3 — Activer la connexion à l’administration (15 min)

Deux possibilités :

**A. Le plus rapide (pour démarrer) : jeton d’accès personnel**
1. GitHub → photo de profil → *Settings* → *Developer settings* → *Personal access tokens* → *Fine-grained tokens* → *Generate new token*.
2. Accès : uniquement le dépôt `foot-talent`, permission **Contents : Read and write**. Durée : 90 jours par exemple.
3. Ouvrez `https://VOTRE-SITE/admin/`, cliquez **« Se connecter avec un jeton d’accès »** et collez le jeton.
   Gardez ce jeton secret, comme un mot de passe.

**B. Recommandé ensuite : bouton « Se connecter avec GitHub »** (plus pratique pour plusieurs rédacteurs)
1. Déployez le petit service gratuit d’authentification **sveltia-cms-auth** sur Cloudflare Workers
   (bouton « Deploy to Cloudflare » sur sa page GitHub officielle : `github.com/sveltia/sveltia-cms-auth`).
2. Créez une application OAuth GitHub (*Settings → Developer settings → OAuth Apps*) avec comme
   *Authorization callback URL* : `https://<votre-worker>.workers.dev/callback`.
3. Renseignez `GITHUB_CLIENT_ID`, `GITHUB_CLIENT_SECRET` et `ALLOWED_DOMAINS` (= votre domaine) dans le Worker.
4. Dans `public/admin/config.yml`, décommentez la ligne `base_url:` et mettez l’adresse du Worker.

**Qui peut publier ?** Uniquement les personnes ajoutées comme collaborateurs du dépôt GitHub
(*Settings → Collaborators*). Pour retirer un accès, retirez la personne du dépôt.

## Étape 4 — Activer la publication programmée (5 min)

1. Cloudflare Pages → votre projet → *Paramètres* → *Builds* → **Deploy hooks** → créez un hook, copiez l’adresse.
2. GitHub → dépôt → *Settings* → *Secrets and variables* → *Actions* → **New repository secret** :
   nom `DEPLOY_HOOK_URL`, valeur = l’adresse copiée.
3. Onglet **Actions** du dépôt : activez les workflows si GitHub le demande.

Chaque heure, une vérification regarde si un article programmé a atteint sa date. Si oui, le site est reconstruit.
Une publication programmée apparaît donc **dans l’heure** qui suit l’horaire choisi.

---

## Publier votre premier vrai article

1. Ouvrez `https://VOTRE-SITE/admin/` et connectez-vous.
2. **Articles → Nouvel article.**
3. Remplissez dans l’ordre :
   - **Titre** et **Chapô** (2–3 phrases de résumé) ;
   - **Rubrique**, **Format** (actualité, portrait, interview…), **Auteur** ;
   - **Image principale** (glissez la photo : elle est automatiquement convertie et allégée), **texte alternatif**
     (ce que montre la photo) et **crédit photo** ;
   - cochez **« J’ai vérifié les droits de toutes les images »** ;
   - si un **joueur mineur** est concerné : cochez la case correspondante **et** la case des autorisations
     des représentants légaux, uniquement quand vous les avez obtenues et archivées ;
   - le **texte** : utilisez « Titre 2 » pour les intertitres. Pour une interview, mettez chaque question en **gras**
     dans son propre paragraphe : elle sera mise en forme automatiquement.
4. Laissez le **Statut** sur « Brouillon » et enregistrez. Utilisez l’onglet **Aperçu** pour relire.
5. Quand tout est prêt : **Statut → Publié**, vérifiez la **date de publication**, enregistrez.
   - Date passée ou actuelle : en ligne en 1 à 2 minutes.
   - Date future : publication automatique à cette heure-là (dans l’heure).

> **Garde-fous automatiques.** Un article n’est jamais publié si : il est en brouillon, sa date est future,
> les droits d’image ne sont pas cochés, ou il concerne un mineur sans autorisations cochées.

## Les autres réglages (menu « Réglages » de l’administration)

- **Page d’accueil** : article à la une, articles « Aussi à la une », pépite du week-end, texte du radar.
- **Radar U17 / U19** : saisissez résultats et prochains matchs. Seules les lignes cochées « Vérifié »
  **avec une source** sont affichées. Rien n’est jamais affiché sans source.
- **Publicités et emplacements** : chaque emplacement peut être désactivé, promouvoir votre offre partenaires,
  ou afficher le visuel d’un annonceur réel (toujours étiqueté « Publicité »).
- **Informations du site** : e-mails, mentions légales, réseaux sociaux, newsletter, formulaire partenaires,
  mesure d’audience, bandeau « site en préparation », autorisation des moteurs de recherche.
- **Clubs**, **Auteurs**, **Rubriques** : menus dédiés. Un club n’apparaît dans « Équipes à suivre »
  que si une justification ou une source est renseignée.

## Brancher la newsletter (Brevo, gratuit jusqu’à 300 e-mails/jour)

1. Créez un compte sur brevo.com → *Contacts* → *Formulaires* → créez un formulaire d’inscription avec double confirmation.
2. Dans *Partager → Code HTML*, repérez l’adresse après `action="…"` et le nom du champ e-mail (souvent `EMAIL`).
3. Administration → Réglages → Informations du site → Newsletter : Service = Brevo, collez l’adresse et le nom du champ.
4. Tant que ce n’est pas fait, le formulaire du site indique honnêtement que l’inscription n’est pas encore ouverte.

## Brancher le formulaire partenaires

Sans réglage, le formulaire ouvre la messagerie du visiteur avec sa demande pré-remplie (aucune perte).
Pour recevoir les demandes directement : créez un formulaire gratuit sur **Formspree** ou **Web3Forms**,
copiez son adresse d’envoi et collez-la dans Réglages → Informations du site → Formulaire partenaires.

## Mesure d’audience

Par défaut, aucune. Options sans cookie (donc sans bandeau de consentement) :
- **Plausible** (payant, environ 9 $/mois pour 10 000 pages vues) : déclarez le site sur plausible.io puis choisissez « Plausible » dans les réglages.
- **Matomo** (auto-hébergé ou Matomo Cloud) : renseignez l’adresse et l’identifiant ; le site le configure sans cookie.
  Ajoutez alors l’adresse de Matomo dans la ligne `Content-Security-Policy` du fichier `public/_headers`.

---

## Sauvegardes et récupération

- **Chaque modification** est enregistrée dans l’historique GitHub : vous pouvez revenir à n’importe quelle version
  d’un article (dépôt → fichier → *History*).
- **Chaque lundi**, une archive des contenus et images est créée (onglet *Actions → Sauvegarde des contenus*), conservée 90 jours.
- **Restauration complète** : téléchargez l’archive, ou reconnectez le dépôt à un nouvel hébergeur (étape 2).
- Conseil : téléchargez une fois par mois le ZIP du dépôt (*Code → Download ZIP*) sur un disque personnel.

## Coûts

| Poste | Coût |
|---|---|
| Hébergement Cloudflare Pages (offre gratuite : 500 constructions/mois) | 0 € |
| GitHub (dépôt privé) | 0 € |
| Administration Sveltia CMS | 0 € |
| Recherche Pagefind | 0 € |
| Nom de domaine `.fr` | environ 10 à 15 € par an selon le registraire |
| Newsletter Brevo (offre gratuite, 300 e-mails/jour) | 0 € au départ |
| Mesure d’audience Plausible (facultatif) | environ 9 $/mois |
| Adresse e-mail professionnelle (facultatif) | quelques euros par mois |

---

## Checklist de lancement

**Contenus**
- [ ] Lancer `npm run demo:remove` (ou supprimer à la main tous les articles, clubs et auteurs « démonstration » dans l’administration)
- [ ] Au moins 6 vrais articles publiés, dont un par rubrique si possible
- [ ] Fiches auteurs réelles (nom, fonction, courte biographie)
- [ ] Article à la une et pépite choisis (Réglages → Page d’accueil)
- [ ] Toutes les photos : droits vérifiés, crédit, texte alternatif
- [ ] Autorisations des représentants légaux archivées pour chaque mineur

**Légal**
- [ ] Mentions légales complétées (éditeur, SIRET, directeur de publication)
- [ ] E-mails de contact réels et relevés
- [ ] Politique de confidentialité relue (elle s’adapte automatiquement aux services activés)

**Technique**
- [ ] Domaine branché, HTTPS actif
- [ ] Adresse du site renseignée dans les réglages et dans `public/admin/config.yml` (`site_url`)
- [ ] Connexion à l’administration testée par chaque rédacteur
- [ ] Secret `DEPLOY_HOOK_URL` configuré, test d’un article programmé
- [ ] Newsletter branchée et testée avec votre propre adresse
- [ ] Formulaire partenaires testé
- [ ] Réseaux sociaux renseignés

**Jour J**
- [ ] Réglages → décocher « bandeau Site en préparation »
- [ ] Réglages → cocher « Autoriser les moteurs de recherche »
- [ ] Déclarer le site dans Google Search Console et y soumettre `https://VOTRE-SITE/sitemap.xml`
- [ ] Partager un premier article sur les réseaux pour vérifier l’aperçu (image et titre)
