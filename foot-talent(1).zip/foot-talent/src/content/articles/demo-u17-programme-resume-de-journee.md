---
statut: "publie"
images_droits_verifies: true
concerne_mineur: false
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "U17 Nationaux : le résumé de journée (exemple de publication programmée)"
chapo: "Cet article est programmé : il n’apparaîtra sur le site qu’à sa date de publication. Il sert à tester la publication différée."
rubrique: "u17-nationaux"
format: "resume"
auteur: "redaction"
date: "2026-10-28T09:00:00+01:00"
image: "/images/demo/tableau-tactique.webp"
image_alt: "Schéma tactique illustratif"
mots_cles:
  - "programmé"
---

> Article de démonstration programmé.

Un résumé de journée ne doit contenir que des résultats vérifiés auprès d’une source officielle, cités avec leur source.
