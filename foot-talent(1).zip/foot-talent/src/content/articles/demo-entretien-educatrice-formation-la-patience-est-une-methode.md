---
statut: "publie"
images_droits_verifies: true
concerne_mineur: false
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "« La patience est une méthode » : entretien avec une éducatrice de formation"
chapo: "Elle encadre des moins de 17 ans depuis dix ans. Exemple d’interview au format questions-réponses, avec une interlocutrice fictive."
rubrique: "interviews"
format: "interview"
auteur: "demo-lea-morvan"
date: "2026-10-22T07:00:00+02:00"
image: "/images/demo/micro-interview.webp"
image_alt: "Illustration d’un micro d’interview devant des lumières de stade floues"
interviewe:
  nom: "Claire Antunes (personnage fictif)"
  fonction: "Éducatrice U17"
citation: "Un joueur ne progresse pas en ligne droite. Notre travail, c’est d’accepter les paliers."
mots_cles:
  - "éducateurs"
  - "méthode"
  - "U17"
---

> Interview de démonstration : la personne interrogée est un personnage fictif.

**Qu’est-ce qui a le plus changé dans la formation depuis vos débuts ?**

La place de la vidéo et du dialogue. Avant, on disait au joueur ce qu’il avait mal fait. Aujourd’hui, on lui montre la séquence et on lui demande ce qu’il a vu. Il trouve souvent la réponse tout seul, et il la retient beaucoup mieux.

**Comment gérez-vous les joueurs qui progressent moins vite ?**

Un joueur ne progresse pas en ligne droite. Notre travail, c’est d’accepter les paliers. Certains stagnent six mois puis franchissent un cap en trois semaines. Si on les juge au mauvais moment, on se trompe.

**Quelle place pour l’école ?**

Centrale. Le football professionnel ne concernera qu’une minorité de nos joueurs. Tous les autres doivent sortir de chez nous avec un diplôme, un projet et de bonnes habitudes de travail. C’est aussi notre responsabilité.

**Un conseil aux parents ?**

Rester des parents. Les jeunes ont déjà un entraîneur. Ce dont ils ont besoin à la maison, c’est de soutien, pas d’une deuxième analyse du match.
