---
statut: "publie"
images_droits_verifies: true
concerne_mineur: false
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "Génération 2010 : ce que les centres de formation cherchent vraiment"
chapo: "Vitesse, technique, mental : derrière les mots qu’on entend partout, les recruteurs de formation décrivent des critères plus fins. Exemple de grand format, rédigé pour la démonstration du site."
rubrique: "centres-de-formation"
format: "analyse"
auteur: "demo-lea-morvan"
date: "2026-10-24T08:30:00+02:00"
image: "/images/demo/stade-nuit.webp"
image_alt: "Illustration d’un stade éclairé de nuit, vu depuis le bord du terrain"
clubs:
  - "demo-fc-valbrune"
  - "demo-as-montclair"
mots_cles:
  - "formation"
  - "recrutement"
  - "U17"
seo_description: "Ce que les centres de formation regardent chez un joueur de 16 ans : un exemple de grand format Foot Talent."
---

> Article de démonstration. Les clubs et personnes cités sont fictifs ; aucune information de cet article ne doit être lue comme une actualité.

Dans un centre de formation, la première observation dure rarement plus d’une mi-temps. Ce n’est pourtant pas le moment où se prend la décision. Ce qui compte, racontent les éducateurs, c’est la répétition : revoir le même joueur sur plusieurs matchs, dans des contextes différents, face à des adversaires de niveaux différents.

## La prise d’information avant le geste

Le critère qui revient le plus souvent n’est pas spectaculaire. Avant de recevoir le ballon, le joueur a-t-il regardé autour de lui ? Sait-il déjà où il va le transmettre ? Cette capacité à « scanner » le jeu se voit dès 15 ou 16 ans, et elle progresse moins vite que la technique pure.

Au FC Valbrune, club fictif imaginé pour cet exemple, les éducateurs filment les séances sous deux angles pour isoler ces moments-là. L’objectif n’est pas de noter le joueur, mais de lui montrer ce qu’il voit et ce qu’il manque.

## La réaction après l’erreur

Deuxième critère : ce qui se passe dans les dix secondes qui suivent une perte de balle. Un joueur qui baisse la tête et un joueur qui repart immédiatement au pressing ne racontent pas la même histoire. Pour un centre de formation, c’est une indication précieuse sur la façon dont il vivra les années difficiles qui l’attendent.

## Le profil physique, avec prudence

Entre 15 et 17 ans, les écarts de maturité physique sont considérables. Les formateurs le savent : un joueur plus petit aujourd’hui peut avoir rattrapé tout le monde dans deux ans. Beaucoup de structures tiennent désormais compte de l’âge biologique, et pas seulement de la date de naissance, pour éviter de passer à côté des profils plus tardifs.

## Ce que cela change pour les familles

Pour les parents, le message des éducateurs est constant : la régularité compte plus qu’un match exceptionnel, et le projet scolaire reste un critère d’équilibre. Un bon centre de formation pose autant de questions sur l’école que sur le terrain.
