---
statut: "publie"
images_droits_verifies: true
concerne_mineur: true
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "Portrait bloqué : autorisations manquantes (exemple de garde-fou)"
chapo: "Cet article concerne un joueur mineur mais les autorisations n’ont pas été cochées : le site refuse de le publier."
rubrique: "jeunes-talents"
format: "portrait"
auteur: "redaction"
date: "2026-10-20T09:00:00+02:00"
image: "/images/demo/maillot-portrait.webp"
image_alt: "Illustration d’un maillot"
---

> Démonstration du garde-fou de protection des mineurs. Cet article n’apparaît jamais sur le site public.
