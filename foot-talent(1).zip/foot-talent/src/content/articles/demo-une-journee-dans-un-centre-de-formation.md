---
statut: "publie"
images_droits_verifies: true
concerne_mineur: false
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "Une journée dans un centre de formation, de 7 h à 21 h"
chapo: "École, entraînement, soins, devoirs : à quoi ressemble le quotidien d’un apprenti footballeur. Reportage de démonstration dans un centre imaginaire."
rubrique: "centres-de-formation"
format: "actualite"
auteur: "demo-lea-morvan"
date: "2026-10-15T08:00:00+02:00"
image: "/images/demo/centre-formation.webp"
image_alt: "Plots et échelle de rythme disposés sur un terrain d’entraînement"
clubs:
  - "demo-as-montclair"
mots_cles:
  - "reportage"
  - "quotidien"
  - "formation"
---

> Reportage de démonstration au sein d’un centre fictif.

7 heures. Le réveil sonne à l’internat de l’AS Montclair, club imaginé pour cet exemple. Avant le premier ballon, il y a le petit-déjeuner, puis la route vers le lycée partenaire.

## Le matin, l’école d’abord

Les emplois du temps sont aménagés, mais les exigences restent les mêmes. Les éducateurs suivent les bulletins de près : un joueur en difficulté scolaire peut voir son temps d’entraînement réduit au profit du soutien.

## L’après-midi, le terrain

La séance du jour porte sur la prise de balle sous pression. Ateliers courts, consignes précises, vidéo en fin de séance.

## Le soir, la récupération

Soins, repas, devoirs. À 21 heures, le calme revient. Demain, tout recommence.
