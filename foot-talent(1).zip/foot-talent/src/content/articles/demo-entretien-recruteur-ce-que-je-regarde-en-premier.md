---
statut: "publie"
images_droits_verifies: true
concerne_mineur: false
autorisations_mineur: false
sponsorise: false
noindex: false
demo: true
image_credit: "Illustration Foot Talent (visuel de démonstration)"
titre: "« Je regarde d’abord ce qu’il fait sans le ballon »"
chapo: "Rencontre avec un recruteur de formation (personnage fictif) qui détaille sa méthode d’observation. Exemple d’interview."
rubrique: "interviews"
format: "interview"
auteur: "redaction"
date: "2026-10-13T07:30:00+02:00"
image: "/images/demo/filet-but.webp"
image_alt: "Ballon dans un filet de but sous les projecteurs"
interviewe:
  nom: "Marc Delorme (personnage fictif)"
  fonction: "Recruteur de formation"
citation: "Un joueur passe 88 minutes sans le ballon. C’est là que je l’observe vraiment."
mots_cles:
  - "recrutement"
  - "observation"
---

> Interview de démonstration : le recruteur interrogé est un personnage fictif.

**Que regardez-vous en premier quand vous observez un joueur ?**

Ce qu’il fait sans le ballon. Un joueur passe l’essentiel du match sans le toucher. C’est là que je l’observe vraiment : ses placements, ses courses, la façon dont il parle à ses partenaires.

**Combien de fois voyez-vous un joueur avant de le recommander ?**

Jamais une seule. Je veux le voir dans un bon match, dans un match difficile, à domicile et à l’extérieur. Une impression ne suffit pas.

**Les statistiques comptent-elles ?**

Elles complètent l’observation, elles ne la remplacent pas. Chez les jeunes, les données sont rares et doivent être maniées avec prudence.
