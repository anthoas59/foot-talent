import { getCollection, getEntry, type CollectionEntry } from 'astro:content';
import reglages from '../data/reglages.json';

export type Article = CollectionEntry<'articles'>;
export type Rubrique = CollectionEntry<'rubriques'>;

export const site = reglages;

/** Raison pour laquelle un article n'est pas visible sur le site public (null = visible). */
export function raisonNonPublie(a: Article, maintenant = new Date()): string | null {
  const d = a.data;
  if (d.statut !== 'publie') return 'brouillon';
  if (d.date.getTime() > maintenant.getTime()) return 'programmé';
  if (d.concerne_mineur && !d.autorisations_mineur) return 'autorisations mineur manquantes';
  if (!d.images_droits_verifies) return "droits d'image non vérifiés";
  return null;
}

let avertissementsAffiches = false;

/** Articles visibles, du plus récent au plus ancien. */
export async function articlesPublies(): Promise<Article[]> {
  const tous = await getCollection('articles');
  const maintenant = new Date();
  if (!avertissementsAffiches) {
    avertissementsAffiches = true;
    for (const a of tous) {
      const r = raisonNonPublie(a, maintenant);
      if (r && r !== 'brouillon' && r !== 'programmé') {
        console.warn(`[Foot Talent] Article non publié (${r}) : ${a.id}`);
      }
    }
  }
  return tous
    .filter((a) => raisonNonPublie(a, maintenant) === null)
    .sort((a, b) => b.data.date.getTime() - a.data.date.getTime());
}

export async function rubriques(): Promise<Rubrique[]> {
  const r = await getCollection('rubriques');
  return r.sort((a, b) => a.data.ordre - b.data.ordre);
}

export async function rubriquesParId(): Promise<Map<string, Rubrique>> {
  return new Map((await rubriques()).map((r) => [r.id, r]));
}

export async function auteursParId() {
  return new Map((await getCollection('auteurs')).map((a) => [a.id, a]));
}

export async function clubsParId() {
  return new Map((await getCollection('clubs')).map((c) => [c.id, c]));
}

export const urlArticle = (a: Article) => `/${a.data.rubrique.id}/${a.id}/`;
export const urlRubrique = (id: string) => `/${id}/`;

const fmtJour = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/Paris' });
const fmtCourt = new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short', timeZone: 'Europe/Paris' });
const fmtHeure = new Intl.DateTimeFormat('fr-FR', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Paris' });

export const dateLongue = (d: Date) => fmtJour.format(d);
export const dateCourte = (d: Date) => fmtCourt.format(d);
export const heure = (d: Date) => fmtHeure.format(d).replace(':', ' h ');

/** Date relative pour les cartes : « Il y a 3 h », « Hier », sinon date courte. */
export function dateCarte(d: Date, maintenant = new Date()) {
  const h = (maintenant.getTime() - d.getTime()) / 36e5;
  if (h < 1) return 'À l’instant';
  if (h < 24) return `Il y a ${Math.floor(h)} h`;
  if (h < 48) return 'Hier';
  return dateCourte(d);
}

export function tempsLecture(texte: string | undefined) {
  const mots = (texte ?? '').split(/\s+/).filter(Boolean).length;
  return Math.max(1, Math.round(mots / 220));
}

export async function articleParId(id: string) {
  return getEntry('articles', id);
}
