import { defineCollection, reference } from 'astro:content';
import { glob } from 'astro/loaders';
import { z } from 'astro/zod';

const rubriques = defineCollection({
  loader: glob({ pattern: '*.json', base: './src/content/rubriques' }),
  schema: z.object({
    nom: z.string(),
    description: z.string(),
    accroche: z.string().optional(),
    ordre: z.number().default(50),
    menu: z.boolean().default(true),
  }),
});

const clubs = defineCollection({
  loader: glob({ pattern: '*.json', base: './src/content/clubs' }),
  schema: z.object({
    nom: z.string(),
    ville: z.string().optional(),
    description: z.string().optional(),
    a_suivre: z.boolean().default(false),
    source_a_suivre: z.string().optional(),
    demo: z.boolean().default(false),
  }),
});

const auteurs = defineCollection({
  loader: glob({ pattern: '*.json', base: './src/content/auteurs' }),
  schema: z.object({
    nom: z.string(),
    role: z.string().optional(),
    bio: z.string().optional(),
    demo: z.boolean().default(false),
  }),
});

const articles = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/articles' }),
  schema: z.object({
    titre: z.string(),
    chapo: z.string(),
    rubrique: reference('rubriques'),
    format: z.enum(['actualite', 'portrait', 'interview', 'analyse', 'resume']).default('actualite'),
    auteur: reference('auteurs'),
    date: z.coerce.date(),
    mise_a_jour: z.coerce.date().optional().nullable(),
    statut: z.enum(['brouillon', 'publie']).default('brouillon'),
    image: z.string(),
    image_alt: z.string(),
    image_credit: z.string(),
    images_droits_verifies: z.boolean().default(false),
    concerne_mineur: z.boolean().default(false),
    autorisations_mineur: z.boolean().default(false),
    clubs: z.array(reference('clubs')).default([]),
    mots_cles: z.array(z.string()).default([]),
    citation: z.string().optional().nullable(),
    interviewe: z.object({ nom: z.string(), fonction: z.string().optional() }).optional().nullable(),
    pepite: z.object({
      nom_affiche: z.string(),
      poste: z.string().optional(),
      categorie: z.string().optional(),
      club: z.string().optional(),
      pourquoi: z.array(z.string()).default([]),
    }).optional().nullable(),
    sponsorise: z.boolean().default(false),
    partenaire_nom: z.string().optional().nullable(),
    partenaire_url: z.string().optional().nullable(),
    seo_titre: z.string().optional().nullable(),
    seo_description: z.string().optional().nullable(),
    noindex: z.boolean().default(false),
    demo: z.boolean().default(false),
  }),
});

export const collections = { rubriques, clubs, auteurs, articles };
