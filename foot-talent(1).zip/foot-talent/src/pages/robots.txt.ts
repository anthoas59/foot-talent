import type { APIContext } from 'astro';
import { site as reglages } from '../lib/contenu';

/** Tant que « Indexation » est désactivée dans les réglages, les moteurs de recherche sont tenus à l'écart. */
export function GET({ site }: APIContext) {
  const corps = reglages.indexation
    ? `User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /recherche/\n\nSitemap: ${new URL('/sitemap.xml', site).href}\n`
    : `# Site en préparation : indexation désactivée (Réglages du site > Autoriser les moteurs de recherche)\nUser-agent: *\nDisallow: /\n`;
  return new Response(corps, { headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
}
