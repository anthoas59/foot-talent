import rss from '@astrojs/rss';
import type { APIContext } from 'astro';
import { articlesPublies, urlArticle, site } from '../lib/contenu';

export async function GET(context: APIContext) {
  const articles = (await articlesPublies()).filter((a) => !a.data.demo);
  return rss({
    title: 'Foot Talent',
    description: site.description,
    site: context.site!,
    items: articles.slice(0, 50).map((a) => ({
      title: a.data.titre,
      description: a.data.chapo,
      pubDate: a.data.date,
      link: urlArticle(a),
      categories: [a.data.rubrique.id, ...(a.data.sponsorise ? ['contenu-partenaire'] : [])],
    })),
    customData: '<language>fr-fr</language>',
  });
}
