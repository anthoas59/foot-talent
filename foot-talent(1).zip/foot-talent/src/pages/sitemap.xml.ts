import type { APIContext } from 'astro';
import { getCollection } from 'astro:content';
import { articlesPublies, rubriques, urlArticle } from '../lib/contenu';

/** Sitemap XML : exclut les contenus de démonstration et ceux marqués « ne pas indexer ». */
export async function GET({ site }: APIContext) {
  const abs = (p: string) => new URL(p, site).href;
  const articles = (await articlesPublies()).filter((a) => !a.data.demo && !a.data.noindex);
  const urls: { loc: string; lastmod?: string }[] = [
    { loc: abs('/') }, { loc: abs('/actualites/') }, { loc: abs('/clubs/') },
    ...(await rubriques()).map((r) => ({ loc: abs(`/${r.id}/`) })),
    ...(await getCollection('clubs')).filter((c) => !c.data.demo && articles.some((a) => a.data.clubs.some((x) => x.id === c.id))).map((c) => ({ loc: abs(`/clubs/${c.id}/`) })),
    ...['/partenaires/', '/newsletter/', '/contact/', '/charte-editoriale/', '/mentions-legales/', '/confidentialite/'].map((p) => ({ loc: abs(p) })),
    ...articles.map((a) => ({ loc: abs(urlArticle(a)), lastmod: (a.data.mise_a_jour ?? a.data.date).toISOString() })),
  ];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map((u) => `  <url><loc>${u.loc}</loc>${u.lastmod ? `<lastmod>${u.lastmod}</lastmod>` : ''}</url>`).join('\n')}\n</urlset>\n`;
  return new Response(xml, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
}
